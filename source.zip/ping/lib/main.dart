import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:clipboard/clipboard.dart';

// --- Firebase Configuration Hardcoded ---
// As requested, this configuration is embedded directly in the app.
const firebaseConfig = {
  "apiKey": "AIzaSyBpgTyenrmFjVQGRhCTlcWfq0EFT8__JRE",
  "authDomain": "ping-application.firebaseapp.com",
  "databaseURL": "https://ping-application-default-rtdb.firebaseio.com",
  "projectId": "ping-application",
  "storageBucket": "ping-application.appspot.com",
  "messagingSenderId": "1056911772808",
  "appId": "1:1056911772808:web:e8ab363defee7ee068a33d",
};
// --- End of Firebase Configuration ---

void main() async {
  // Ensure Flutter is ready
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Firebase with the hardcoded options
  await Firebase.initializeApp(
    options: FirebaseOptions(
      apiKey: firebaseConfig['apiKey']!,
      appId: firebaseConfig['appId']!,
      messagingSenderId: firebaseConfig['messagingSenderId']!,
      projectId: firebaseConfig['projectId']!,
      databaseURL: firebaseConfig['databaseURL'],
    ),
  );
  
  runApp(const PingApp());
}

class PingApp extends StatelessWidget {
  const PingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ping',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF0F2F5),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black87,
          elevation: 1,
        ),
      ),
      home: const PermissionScreen(),
    );
  }
}

// Screen 1: Asks for microphone permission on first launch
class PermissionScreen extends StatefulWidget {
  const PermissionScreen({super.key});

  @override
  State<PermissionScreen> createState() => _PermissionScreenState();
}

class _PermissionScreenState extends State<PermissionScreen> {
  @override
  void initState() {
    super.initState();
    _checkAndRequestPermission();
  }

  Future<void> _checkAndRequestPermission() async {
    var status = await Permission.microphone.status;
    if (status.isGranted) {
      _navigateToMain();
    }
  }

  void _navigateToMain() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (context) => const MainUIScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Card(
          margin: const EdgeInsets.all(24),
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Welcome to Ping', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.blue)),
                const SizedBox(height: 16),
                const Text('This app requires microphone access to make voice calls.', textAlign: TextAlign.center, style: TextStyle(fontSize: 16)),
                const SizedBox(height: 24),
                ElevatedButton.icon(
                  icon: const Icon(Icons.mic),
                  onPressed: () async {
                    if (await Permission.microphone.request().isGranted) {
                      _navigateToMain();
                    } else {
                       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                           content: Text('Microphone permission is required to use the app.'),
                       ));
                    }
                  },
                  label: const Text('Allow Microphone'),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.blue, foregroundColor: Colors.white),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


// Screen 2: Main UI for creating or joining a group
class MainUIScreen extends StatefulWidget {
  const MainUIScreen({super.key});

  @override
  State<MainUIScreen> createState() => _MainUIScreenState();
}

class _MainUIScreenState extends State<MainUIScreen> {
  final _usernameController = TextEditingController();
  String _username = '';

  @override
  void initState() {
    super.initState();
    _loadUsername();
  }
    
  Future<void> _loadUsername() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _username = prefs.getString('ping-username') ?? '';
      _usernameController.text = _username;
    });
  }

  Future<void> _saveUsername() async {
    final prefs = await SharedPreferences.getInstance();
    if (_usernameController.text.trim().isNotEmpty) {
      setState(() { _username = _usernameController.text.trim(); });
      await prefs.setString('ping-username', _username);
      FocusScope.of(context).unfocus(); // Dismiss keyboard
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Username saved!'), duration: Duration(seconds: 2)),
      );
    }
  }

   bool _checkUsername() {
    if (_username.isEmpty) {
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Username Required'),
          content: const Text('Please enter and save a username first.'),
          actions: [ TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('OK')) ],
        ),
      );
      return false;
    }
    return true;
  }
  
  void _showMakeGroupDialog() {
    if (!_checkUsername()) return;
    final code = (1000 + Random().nextInt(9000)).toString();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('Your Group Code'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Share this code with others:'),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
              decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(8)),
              child: Text(code, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, letterSpacing: 4)),
            ),
          ],
        ),
        actions: [
          IconButton(
             icon: const Icon(Icons.copy),
             onPressed: () => FlutterClipboard.copy(code).then((_) => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Code copied!')))),
          ),
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () => _joinCall(code, context),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
            child: const Text('Start Call'),
          ),
        ],
      ),
    );
  }

  void _showJoinGroupDialog() {
    if (!_checkUsername()) return;
    final codeController = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Join a Group'),
        content: TextField(
          controller: codeController,
          decoration: const InputDecoration(hintText: 'Enter 4-digit code', border: OutlineInputBorder()),
          keyboardType: TextInputType.number,
          maxLength: 4,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              final code = codeController.text.trim();
              if (code.length != 4) return;
              final snapshot = await FirebaseDatabase.instance.ref('groups/$code').once();
              if (!context.mounted) return;
              if (snapshot.snapshot.exists) {
                  _joinCall(code, context);
              } else {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Group not found!')));
              }
            },
            child: const Text('Join'),
          ),
        ],
      ),
    );
  }

   void _joinCall(String groupCode, BuildContext dialogContext) {
    Navigator.of(dialogContext).pop(); // Close the dialog first
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => CallScreen(groupCode: groupCode, username: _username),
    ));
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ping - Group Voice Call')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  TextField(
                    controller: _usernameController,
                    decoration: InputDecoration(
                      labelText: 'Enter Your Username',
                      border: const OutlineInputBorder(),
                      suffixIcon: IconButton(icon: const Icon(Icons.save), onPressed: _saveUsername),
                    ),
                  ),
                  const Divider(height: 48, thickness: 1),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.group_add),
                    onPressed: _showMakeGroupDialog,
                    label: const Text('Make a Group'),
                    style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 12)),
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    icon: const Icon(Icons.login),
                    onPressed: _showJoinGroupDialog,
                    label: const Text('Join a Group'),
                    style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 12)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// Screen 3: The active call UI
class CallScreen extends StatefulWidget {
  final String groupCode;
  final String username;

  const CallScreen({super.key, required this.groupCode, required this.username});

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> with WidgetsBindingObserver {
  final FirebaseDatabase _database = FirebaseDatabase.instance;
  MediaStream? _localStream;
  final Map<String, RTCPeerConnection> _peerConnections = {};
  final List<String> _users = [];
  bool _isMuted = false;
  
  // To prevent memory leaks
  late final StreamSubscription<DatabaseEvent> _userAddedSubscription;
  late final StreamSubscription<DatabaseEvent> _userRemovedSubscription;
  late final StreamSubscription<DatabaseEvent> _signalSubscription;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initializeCall();
  }

  Future<void> _initializeCall() async {
    _localStream = await navigator.mediaDevices.getUserMedia({'audio': true, 'video': false});
    
    final groupRef = _database.ref('groups/${widget.groupCode}');
    final userRef = groupRef.child('users').child(widget.username);
    await userRef.set({'joined': true});
    userRef.onDisconnect().remove();

    _userAddedSubscription = groupRef.child('users').onChildAdded.listen((event) {
      final newUser = event.snapshot.key!;
      if (!mounted) return;
      setState(() { if (!_users.contains(newUser)) _users.add(newUser); });
      if (newUser != widget.username) { _createPeerConnection(newUser, isInitiator: true); }
    });

    _userRemovedSubscription = groupRef.child('users').onChildRemoved.listen((event) {
      _handleUserLeaving(event.snapshot.key!);
    });
    
    _signalSubscription = _database.ref('signals/${widget.groupCode}/${widget.username}').onValue.listen(_handleSignal);
  }
  
  Future<void> _createPeerConnection(String otherUser, {required bool isInitiator}) async {
    final pc = await createPeerConnection({
      'iceServers': [ {'urls': 'stun:stun.l.google.com:19302'} ]
    }, {});
    
    _localStream?.getTracks().forEach((track) { pc.addTrack(track, _localStream!); });

    pc.onIceCandidate = (candidate) {
      if (candidate != null) { _sendSignal(otherUser, {'ice': candidate.toMap()}); }
    };
    
    _peerConnections[otherUser] = pc;
    
    if (isInitiator) {
        final offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        _sendSignal(otherUser, {'offer': offer.toMap()});
    }
  }
  
  Future<void> _handleSignal(DatabaseEvent event) async {
    if (event.snapshot.value == null) return;
    final data = Map<String, dynamic>.from(event.snapshot.value as Map);
    final fromUser = data['from'];
    if (fromUser == null) return;

    if (_peerConnections[fromUser] == null) { await _createPeerConnection(fromUser, isInitiator: false); }
    final pc = _peerConnections[fromUser]!;
    
    if (data['offer'] != null) {
        await pc.setRemoteDescription(RTCSessionDescription(data['offer']['sdp'], data['offer']['type']));
        final answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        _sendSignal(fromUser, {'answer': answer.toMap()});
    } else if (data['answer'] != null) {
        await pc.setRemoteDescription(RTCSessionDescription(data['answer']['sdp'], data['answer']['type']));
    } else if (data['ice'] != null) {
        pc.addCandidate(RTCIceCandidate(data['ice']['candidate'], data['ice']['sdpMid'], data['ice']['sdpMLineIndex']));
    }
    event.snapshot.ref.remove();
  }

  void _sendSignal(String toUser, Map<String, dynamic> data) {
    _database.ref('signals/${widget.groupCode}/$toUser').set({ ...data, 'from': widget.username });
  }
  
  void _handleUserLeaving(String leftUser) {
    if (!mounted) return;
    setState(() { _users.remove(leftUser); });
    _peerConnections[leftUser]?.close();
    _peerConnections.remove(leftUser);
  }
  
  void _toggleMute() {
    if (_localStream?.getAudioTracks().isNotEmpty ?? false) {
      final audioTrack = _localStream!.getAudioTracks()[0];
      setState(() {
        audioTrack.enabled = !audioTrack.enabled;
        _isMuted = !audioTrack.enabled;
      });
    }
  }

  Future<void> _endCall() async {
    await _cleanUp();
    if (mounted) Navigator.of(context).pop();
  }
  
  Future<void> _cleanUp() async {
    // Cancel all stream subscriptions to prevent memory leaks
    await _userAddedSubscription.cancel();
    await _userRemovedSubscription.cancel();
    await _signalSubscription.cancel();

    _localStream?.getTracks().forEach((track) => track.stop());
    _localStream?.dispose();
    
    for (var pc in _peerConnections.values) { pc.close(); }
    _peerConnections.clear();
    
    // Remove user from database
    final userRef = _database.ref('groups/${widget.groupCode}/users/${widget.username}');
    if ((await userRef.once()).snapshot.exists) { await userRef.remove(); }
  }
  
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.detached) _endCall();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _cleanUp();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (_) => _endCall(),
      child: Scaffold(
        appBar: AppBar(
          title: Text('In Call - Code: ${widget.groupCode}'),
          automaticallyImplyLeading: false,
        ),
        body: Column(
          children: [
            Expanded(
              child: _users.isEmpty
                  ? const Center(child: Text('Waiting for others to join...'))
                  : ListView.builder(
                      itemCount: _users.length,
                      itemBuilder: (ctx, index) {
                        final user = _users[index];
                        return Card(
                          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                          child: ListTile(
                            leading: const Icon(Icons.person),
                            title: Text(user, style: TextStyle(fontWeight: user == widget.username ? FontWeight.bold : FontWeight.normal)),
                            trailing: user == widget.username ? const Text('(You)') : null,
                          ),
                        );
                      },
                    ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
              color: Colors.white,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  FloatingActionButton(
                    heroTag: 'muteBtn',
                    onPressed: _toggleMute,
                    backgroundColor: _isMuted ? Colors.grey : Colors.blue,
                    child: Icon(_isMuted ? Icons.mic_off : Icons.mic, color: Colors.white),
                  ),
                  FloatingActionButton(
                    heroTag: 'endCallBtn',
                    onPressed: _endCall,
                    backgroundColor: Colors.red,
                    child: const Icon(Icons.call_end, color: Colors.white),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}